// import React from "react";
// import styles from "./ClickableBtn.module.scss";
// import classNames from "classnames/bind";

// const cx = classNames.bind(styles);

// const ClickableButton = () => {
//   const handleClick = () => {
//     const button = document.querySelector(".h-button");
//     button.classList.toggle("clicked");
//   };

//   return (
//     <button
//       className="h-button centered"
//       data-text="Click me"
//       href="#"
//       onClick={handleClick}
//     >
//       <span>T</span>
//       <span>h</span>
//       <span>a</span>
//       <span>n</span>
//       <span>k</span>
//       <span>s</span>
//     </button>
//   );
// };

// export default ClickableButton;
